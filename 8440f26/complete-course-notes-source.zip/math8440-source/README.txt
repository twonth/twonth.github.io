MATH 8440 — COMPLETE COURSE NOTES

194 slides, including the four-slide BONUS proving sum mu(n)/n = 0.

This is fully editable LaTeX: all text, formulas, tables, and diagrams are
native source. It does not include or depend on pages from an existing PDF.
The full source was reconstructed from the revised course PDF; the bonus
proves the vanishing of the reciprocal-weighted Möbius sum. Earlier edits had been assembled directly
into the PDF, rather than maintained in a complete TeX document.

BUILD
  Compile main.tex twice with XeLaTeX, or run:
    tectonic main.tex
  Required packages: beamer, amsmath, amssymb, mathtools, lmodern,
  booktabs, tikz (and their standard dependencies).

EDITING
  main.tex contains the appearance settings and includes the section files.
  sections/08-bonus.tex contains the bonus proof.
  The contents-page numbers are explicit. If slides are added or removed,
  update the relevant sections/toc-*.tex files and their navigation links.

A standalone copy with all sections expanded is also supplied as
math8440-complete-course-notes.tex. Compiling it produces the same content.
